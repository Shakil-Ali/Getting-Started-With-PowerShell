#Demo - Formatting
Get-Service
cls
Get-Service | Format-List
cls
Get-Service | Format-List Name,Status
cls
get-service | Format-Table
cls
get-service | Format-Table -AutoSize
cls
get-service | Format-Table -Wrap
cls
get-service | Format-Table -Wrap name,DisplayName
cls
